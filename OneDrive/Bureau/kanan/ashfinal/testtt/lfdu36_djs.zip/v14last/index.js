const { Client, GatewayIntentBits, Partials, Collection, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const client = new Client({
	intents: [
		GatewayIntentBits.Guilds, 
		GatewayIntentBits.GuildMessages, 
		GatewayIntentBits.GuildPresences, 
		GatewayIntentBits.GuildMessageReactions, 
		GatewayIntentBits.DirectMessages,
		GatewayIntentBits.GuildMembers,
		GatewayIntentBits.MessageContent
	], 
	partials: [Partials.Channel, Partials.Message, Partials.User, Partials.GuildMember, Partials.Reaction] 
});

const {token} = require('./config.json')

const config = require('./config.json');
require('dotenv').config()

client.commands = new Collection()
client.aliases = new Collection()
client.slashCommands = new Collection();
client.prefix = config.prefix

module.exports = client;

[ 'slashCommand', 'events'].forEach((handler) => {
  require(`./handlers/${handler}`)(client)
});

const InvitesTracker = require('@androz2091/discord-invites-tracker');
const tracker = InvitesTracker.init(client, {
    fetchGuilds: true,
    fetchVanity: true,
    fetchAuditLogs: true
});

tracker.on('guildMemberAdd', (member, type, invite) => {
	const welcomeChannel = member.guild.channels.cache.find((ch) => ch.name === 'logs');
	const sendEmbed = (description) => {
		const embedSend = new EmbedBuilder()
		.setTitle('Invite Tracker')
		.setDescription(description)
		.setColor(0x5865f2);

		welcomeChannel.send({embeds: [embedSend]});
	}
    if(type === 'normal') {
		sendEmbed(`Bienvenue ${member}! Tu as été invité par ${invite.inviter.username}!`)
    }
    else if(type === 'vanity') {
		sendEmbed(`Bienvenue ${member}! Tu as rejoins en utilisant une invitation customisé !!`)
    }
    else if(type === 'permissions') {
        sendEmbed(`Bienvenue ${member}! Je ne peux pas te dire comment tu as rejoins le serveur, car je n'ai pas la permission 'Manage Server'`);
    }
    else if(type === 'unknown') {
        sendEmbed(`Bienvenue ${member}! Je ne peux pas te dire comment tu as rejoins le serveur...`);
    }
});

client.login(token);