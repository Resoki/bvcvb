const { ApplicationCommandType, ApplicationCommandOptionType,ChannelType, PermissionFlagsBits } = require('discord.js');
const { joinVoiceChannel } = require('@discordjs/voice');
module.exports = {
	name: 'channel',
	description: "Afficher son profil",
	type: ApplicationCommandType.ChatInput,
    category: "utility",
	cooldown: 3000,
	run: async (client, interaction) => {
        let ticketname = `${interaction.member.user.username}`
		const createdChannel = await interaction.guild.channels.create({
            name: ticketname,
            type: ChannelType.GuildVoice,
            permissionOverwrites: [
                {
                    allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
                    id: interaction.member.user.id,
                },
                {
                    deny: [PermissionFlagsBits.ViewChannel],
                    id: interaction.guild.id,
                },
            ],
        }).then((channel)=> {
           joinVoiceChannel({
                channelId: channel.id,
                guildId: channel.guild.id,
                selfDeaf: false,
                adapterCreator: channel.guild.voiceAdapterCreator,
            });
        })
    }        
};