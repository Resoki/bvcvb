const { ApplicationCommandType,  
    ApplicationCommandOptionType, 
    EmbedBuilder, 
    ActionRowBuilder,
ButtonBuilder }  = require('discord.js');
const ts = require('djs-tickets')
module.exports = {
name: 'ticket',
description: "Faire parler le bot",
type: ApplicationCommandType.ChatInput,
category: "utility",
cooldown: 3000,
    options: [{
        name: 'channel',
        description: 'Le channel ou envoyer',
        type: ApplicationCommandOptionType.Channel,
        require: true
    }],
run: async (client, interaction) => {
    try {
        const channel = interaction.options.getChannel("channel");

        const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
            .setStyle("Secondary")
            .setEmoji("📩")
            .setCustomId("create-ticket")
        );

        const embed = new EmbedBuilder()
        .setTitle("Create ticket")
        .setDescription("Pour créer un ticket, réagis avec 📩")
        .setColor(0x5865f2)

        await interaction.reply({ content: `Le pannel de ticket a été envoyé dans le channel > <#${channel.id}>!`, ephemeral: true });
        return channel.send({ embeds: [embed], components: [row] });
    }
    catch(err) {
        console.log(err)
        return interaction.reply(`Une erreur a eu lieu:\n${err}`);
        console.log(err)
    }
}
};