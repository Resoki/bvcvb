const client = require('..')

client.on('messageCreate', async message => {
	try {
        if(message.content.includes('http' || message.content.includes('www.'))) {
            message.delete();
            message.channel.send(`<@${message.author.id}>, ton message a été supprimé car il comportait un lien ! 🔗`, ephemeral = true)
        }
    }
    catch(err){
        return console.log(err);
    }
});