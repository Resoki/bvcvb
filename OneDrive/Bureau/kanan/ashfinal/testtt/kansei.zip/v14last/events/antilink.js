const client = require('..')
const { PermissionsBitField } = require("discord.js");

client.on('messageCreate', async message => {
	try {
        if(message.content.includes('http' || message.content.includes('www.'))) {
            if(message.content.includes('gif' )) {
                return;
            }
            if (message.member.permissions.has(PermissionsBitField.Flags.KickMembers)) return;
            message.delete();
            return message.channel.send(`<@${message.author.id}>, ton message a été supprimé car il comportait un lien ! 🔗`, ephemeral = true);
        }
    }
    catch(err) {
        return console.log(err);
    }
});