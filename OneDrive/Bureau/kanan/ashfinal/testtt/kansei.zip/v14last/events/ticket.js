const { ButtonBuilder, EmbedBuilder, PermissionFlagsBits,PermissionsBitField, ActionRowBuilder,ChannelType, Embed } = require('discord.js');
const client = require('..');
const global = require('../config.json');
const sourcebin = require('sourcebin_js');


client.on('interactionCreate', async interaction => {

        if (!interaction.isButton()) return;

        if (interaction.customId === 'create-ticket') {
            let ticketName = (`ticket-${interaction.member.user.username}`).toLowerCase();
            let supportRoles = global.ticketsSupportRoles.map(x => {
                return {
                    id: x,
                    allow: ["VIEW_CHANNEL", "SEND_MESSAGES", "ATTACH_FILES", "EMBED_LINKS", "MANAGE_MESSAGES"]
                }
            });

            await interaction.reply({ content: `Creating ticket...`, ephemeral: true });

          if (interaction.guild.channels.cache.find(c =>  c.name.includes(`${ticketName}`))) return interaction.editReply({ content: `You have already created a ticket!`, ephemeral: true });

            const createdChannel = await interaction.guild.channels.create({
                name: ticketName,
                type: ChannelType.GuildText,
                permissionOverwrites: [
                    {
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
                        id: interaction.member.user.id,
                    },
                    {
                        deny: [PermissionFlagsBits.ViewChannel],
                        id: interaction.guild.id,
                    },
                ],
            }).then(async(channel)=> {
                const embedTicket = new EmbedBuilder()
                .setTitle('Ticket !')
                .setDescription(`Bienvenue <@${interaction.member.user.id}> dans ton ticket !\nUn staff vous assistera
                dans quelques instants. Formulez votre demande.`)
                .setColor(0x0FF)
                .setTimestamp();

             
            const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('close-ticket')
                    .setLabel('🗑️')
                    .setStyle('Danger')
            );

               await channel.send({embeds: [embedTicket], components: [row]});
            })
            
            await interaction.editReply({ content: `Ticket crée avec success !` , ephemeral: true });

        }

        if(interaction.customId === 'close-ticket') {
            if (!interaction.member.permissions.has(PermissionsBitField.Flags.KickMembers)) {
                return interaction.channel.send(`❌ | Tu n'as pas la permission de fermer le ticket !`, ephemeral = true)
              }
            const embedCancel = new EmbedBuilder()
            .setTitle('Supprimer le ticket ?')
            .setColor(0x0FF)
            .setTimestamp();

            const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('delete-ticket')
                    .setLabel('Oui')
                    .setStyle('Primary'),
            );
            await interaction.reply({embeds: [embedCancel], components: [row], ephemeral: true});
        }
        if(interaction.customId === 'delete-ticket') {  
            if (!interaction.isButton()) return;
                const transcriptsChannel = client.channels.cache.get('965591338873663519') 
                let msg = await interaction.channel.send({ content: 'Saving transcript...' });
               interaction.channel.messages.fetch().then(async (messages) => {
                    const content = messages.reverse().map(m => `${new Date(m.createdAt).toLocaleString('en-US')} - ${m.author.tag}: ${m.attachments.size > 0 ? m.attachments.first().proxyURL : m.content}`).join('\n');
    
                    let transcript = await sourcebin.create([{ name: `${interaction.channel.name}`, content: content, languageId: 'text' }], {
                        title: `Chat transcript: ${interaction.channel.name}`,
                        description: ' ',
                    });
            
                    const row = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                        .setStyle("Link")
                        .setEmoji("📑")
                        .setURL(`${transcript.url}`)
                    );
            
                    const embed = new EmbedBuilder()
                    .setTitle("Ticket Fermé")
                    .addFields(
                        { name: "📝 Channel", value: `${interaction.channel.name}`, inline: true },
                        { name: "🔒 Fermé par", value: `<@!${interaction.member.user.id}>` },
                        { name: "📜 Direct Transcript", value: `[Direct Transcript](${transcript.url})` }
                    )
                    .setColor(0x0dff3)
                    .setTimestamp()
            
                    await transcriptsChannel.send({ embeds: [embed], components: [row] });
                });
    
            await msg.edit({ content: `Transcript sauvegardé ` });
    
            await interaction.channel.send(`Le ticket va êter **fermé** dans 3 secondes.`);
            setTimeout(async()=> {
                await interaction.channel.delete();
            }, 3000)
        }
})