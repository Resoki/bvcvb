const client = require('..')
const { Collection, EmbedBuilder } = require('discord.js')

client.on('messageCreate', async message => {
    if (message.author.bot) return;
    if (!message.channel || !message.channel.name) return
  
    if (message.channel.name.includes(`${message.author.username.toLowerCase()}`)){
        const embedSuccess = new EmbedBuilder()
        .setTitle(`${message.channel.name}`)
        .setDescription(`${message.author.tag}:\n${message.content?message.content:message.attachents.last().url}`)
        .setColor(0x983F)
        .setTimestamp();

        
       let user = await client.users.fetch('167718852984176641');
       user.send({embeds: [embedSuccess]})
    }
})