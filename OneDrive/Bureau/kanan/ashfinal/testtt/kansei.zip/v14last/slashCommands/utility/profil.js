const { ApplicationCommandType, ApplicationCommandOptionType, EmbedBuilder } = require('discord.js');

module.exports = {
	name: 'profil',
	description: "Afficher son profil",
	type: ApplicationCommandType.ChatInput,
  category: "utility",
	cooldown: 3000,
  options: [
    {
      name: 'user',
      description:`L'user`,
      type: ApplicationCommandOptionType.User,
      required: false
    }
  ],
	run: async (client, interaction) => {
		const user = interaction.options.getUser('user');

    const embedGenerator = async(user) => {
      const member = interaction.guild.members.cache.get(user.id);

      const isBot = member.user.bot ? '🤖 Bot: OUI ✅' : '🤖 Bot: NON ❌';
      const joinGuildOn = member.guild.joinedTimestamp;
      const roles = member._roles
      let tabRole = [];

      const milliseconds = joinGuildOn // 1575909015000
      const dateObject = new Date(milliseconds)
      const humanDateFormat = dateObject.toLocaleString() //2019-12-9 10:30:15

      await roles.forEach(async(element) => {
        tabRole.push(`<@&${element}>`)
      }) 

      const embedProfil = new  EmbedBuilder()
      .setTitle(`${member.user.username}#${member.user.discriminator}`)
      .addFields({name: `Infos =>`, value: `Rejoin le serveur le: ${humanDateFormat}\n${isBot}`})
      .addFields({name: `Rôle (${tabRole.length === 0 ?  '0' : tabRole.length}) =>`, value: `📛 ${tabRole}`, inline: true})
      .setColor(0x5865f2)
      .setThumbnail(user.displayAvatarURL())
      .setTimestamp();

      return interaction.reply({embeds: [embedProfil]});
    }

    if(!user) return embedGenerator(interaction.member.user);
    return embedGenerator(user);
	}
};